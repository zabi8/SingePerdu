﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormCORRIGER
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.an1 = New System.Windows.Forms.PictureBox()
        Me.an2 = New System.Windows.Forms.PictureBox()
        Me.an3 = New System.Windows.Forms.PictureBox()
        Me.an4 = New System.Windows.Forms.PictureBox()
        Me.an5 = New System.Windows.Forms.PictureBox()
        Me.an6 = New System.Windows.Forms.PictureBox()
        Me.an7 = New System.Windows.Forms.PictureBox()
        Me.an8 = New System.Windows.Forms.PictureBox()
        Me.an9 = New System.Windows.Forms.PictureBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.an1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.an2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.an3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.an4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.an5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.an6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.an7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.an8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.an9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox1.Location = New System.Drawing.Point(235, 74)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(97, 90)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox2.Location = New System.Drawing.Point(332, 74)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(97, 90)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 1
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox3.Location = New System.Drawing.Point(429, 74)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(97, 90)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 2
        Me.PictureBox3.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.PictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox4.Location = New System.Drawing.Point(235, 164)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(97, 90)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 5
        Me.PictureBox4.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox5.Location = New System.Drawing.Point(332, 164)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(97, 90)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 4
        Me.PictureBox5.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.PictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox6.Location = New System.Drawing.Point(429, 164)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(97, 90)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox6.TabIndex = 3
        Me.PictureBox6.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.PictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox7.Location = New System.Drawing.Point(235, 254)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(97, 90)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox7.TabIndex = 8
        Me.PictureBox7.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.PictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox8.Location = New System.Drawing.Point(332, 254)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(97, 90)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox8.TabIndex = 7
        Me.PictureBox8.TabStop = False
        '
        'PictureBox9
        '
        Me.PictureBox9.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.PictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox9.Location = New System.Drawing.Point(429, 254)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(97, 90)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox9.TabIndex = 6
        Me.PictureBox9.TabStop = False
        '
        'an1
        '
        Me.an1.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.gg1
        Me.an1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.an1.Location = New System.Drawing.Point(33, -3)
        Me.an1.Name = "an1"
        Me.an1.Size = New System.Drawing.Size(97, 90)
        Me.an1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.an1.TabIndex = 17
        Me.an1.TabStop = False
        '
        'an2
        '
        Me.an2.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.gg2
        Me.an2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.an2.Location = New System.Drawing.Point(184, -22)
        Me.an2.Name = "an2"
        Me.an2.Size = New System.Drawing.Size(97, 90)
        Me.an2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.an2.TabIndex = 16
        Me.an2.TabStop = False
        '
        'an3
        '
        Me.an3.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.gg3
        Me.an3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.an3.Location = New System.Drawing.Point(287, -13)
        Me.an3.Name = "an3"
        Me.an3.Size = New System.Drawing.Size(97, 90)
        Me.an3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.an3.TabIndex = 15
        Me.an3.TabStop = False
        '
        'an4
        '
        Me.an4.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.gg4
        Me.an4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.an4.Location = New System.Drawing.Point(-3, 164)
        Me.an4.Name = "an4"
        Me.an4.Size = New System.Drawing.Size(97, 90)
        Me.an4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.an4.TabIndex = 14
        Me.an4.TabStop = False
        '
        'an5
        '
        Me.an5.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.gg5
        Me.an5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.an5.Location = New System.Drawing.Point(117, 174)
        Me.an5.Name = "an5"
        Me.an5.Size = New System.Drawing.Size(97, 90)
        Me.an5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.an5.TabIndex = 13
        Me.an5.TabStop = False
        '
        'an6
        '
        Me.an6.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.gg6
        Me.an6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.an6.Location = New System.Drawing.Point(654, 185)
        Me.an6.Name = "an6"
        Me.an6.Size = New System.Drawing.Size(97, 90)
        Me.an6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.an6.TabIndex = 12
        Me.an6.TabStop = False
        '
        'an7
        '
        Me.an7.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.gg7
        Me.an7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.an7.Location = New System.Drawing.Point(23, 320)
        Me.an7.Name = "an7"
        Me.an7.Size = New System.Drawing.Size(97, 90)
        Me.an7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.an7.TabIndex = 11
        Me.an7.TabStop = False
        '
        'an8
        '
        Me.an8.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.gg8
        Me.an8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.an8.Location = New System.Drawing.Point(158, 350)
        Me.an8.Name = "an8"
        Me.an8.Size = New System.Drawing.Size(97, 90)
        Me.an8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.an8.TabIndex = 10
        Me.an8.TabStop = False
        '
        'an9
        '
        Me.an9.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.gg9
        Me.an9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.an9.Location = New System.Drawing.Point(320, 350)
        Me.an9.Name = "an9"
        Me.an9.Size = New System.Drawing.Size(97, 90)
        Me.an9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.an9.TabIndex = 9
        Me.an9.TabStop = False
        '
        'Timer1
        '
        '
        'FormCORRIGER
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.an1)
        Me.Controls.Add(Me.an2)
        Me.Controls.Add(Me.an3)
        Me.Controls.Add(Me.an4)
        Me.Controls.Add(Me.an5)
        Me.Controls.Add(Me.an6)
        Me.Controls.Add(Me.an7)
        Me.Controls.Add(Me.an8)
        Me.Controls.Add(Me.an9)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.PictureBox8)
        Me.Controls.Add(Me.PictureBox9)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "FormCORRIGER"
        Me.Text = "SINGE PERDU"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.an1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.an2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.an3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.an4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.an5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.an6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.an7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.an8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.an9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents an1 As PictureBox
    Friend WithEvents an2 As PictureBox
    Friend WithEvents an3 As PictureBox
    Friend WithEvents an4 As PictureBox
    Friend WithEvents an5 As PictureBox
    Friend WithEvents an6 As PictureBox
    Friend WithEvents an7 As PictureBox
    Friend WithEvents an8 As PictureBox
    Friend WithEvents an9 As PictureBox
    Friend WithEvents Timer1 As Timer
End Class
