﻿Public Class Form6
    Private Sub Form6_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Formmonster.Visible = False
        Timer1.Start()
    End Sub
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        FormCORRIGER.Visible = True
    End Sub
    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        FormQUESTIONNAIRE.Visible = True
    End Sub
    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        FormTROUVE.Visible = True
    End Sub
    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click
        FormCHASSE.Visible = True
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If game1 = 2 Then
            PictureBox1.Image = My.Resources.CORRIGERX
            PictureBox1.Enabled = False
        End If
        If game2 = 2 Then
            PictureBox2.Image = My.Resources.QUESTIONNAIREX
            PictureBox2.Enabled = False
        End If

        If game3 = 2 Then
            PictureBox3.Image = My.Resources.TROUVEX
            PictureBox3.Enabled = False
        End If

        If game4 = 2 Then
            PictureBox4.Image = My.Resources.CHASSEX
            PictureBox4.Enabled = False
        End If

        If gametotal = 4 Then
            FormEND.Visible = True
        End If
    End Sub

End Class