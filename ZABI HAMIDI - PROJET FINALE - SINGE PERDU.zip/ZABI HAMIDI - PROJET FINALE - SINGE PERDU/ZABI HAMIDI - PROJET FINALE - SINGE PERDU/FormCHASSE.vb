﻿Public Class FormCHASSE
    Dim x As Integer = 0
    Private Sub Timer5_Tick(sender As Object, e As EventArgs) Handles Timer5.Tick

        If MOT.Top > SINGE.Top Then
            MOT.Location = New Point(MOT.Location.X, MOT.Location.Y + 1)
        End If
        If MOT.Left > SINGE.Left Then
            MOT.Location = New Point(MOT.Location.X + 1, MOT.Location.Y)
        End If
        If MOT.Top < SINGE.Top Then
            MOT.Location = New Point(MOT.Location.X, MOT.Location.Y - 1)
        End If
        If MOT.Left < SINGE.Left Then
            MOT.Location = New Point(MOT.Location.X - 1, MOT.Location.Y)
        End If

        If MOT.Bounds.IntersectsWith(SINGE.Bounds) Then
            Timer5.Stop()
            gametotal += 1
            If Not gametotal = 4 Then
                game4 = 2
                MsgBox(Title:="MISSION ACCOMPLI", Prompt:="BRAVO! VOUS AVEZ CHASSER LE MOT!")
                MsgBox(Title:="MISSION ACCOMPLI", Prompt:="IL VOUS RESTE " & 4 - gametotal & " MISSIONS!")
                Me.Dispose()
                Form6.Visible = True
            End If
        End If

    End Sub

    Private Sub FormCHASSE_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()
        Timer5.Start()
    End Sub

    Private Sub FormCHASSE_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        Select Case e.KeyCode
            Case Keys.W
                Timer2.Stop()
                Timer3.Stop()
                Timer4.Stop()
                SINGE.Location = New Point(SINGE.Location.X, SINGE.Location.Y - 5)
                Timer1.Start()
            Case Keys.S
                Timer1.Stop()
                Timer3.Stop()
                Timer4.Stop()
                SINGE.Location = New Point(SINGE.Location.X, SINGE.Location.Y + 5)
                Timer2.Start()
            Case Keys.D
                Timer1.Stop()
                Timer2.Stop()
                Timer4.Stop()

                SINGE.Location = New Point(SINGE.Location.X + 5, SINGE.Location.Y)
                Timer3.Start()
            Case Keys.A
                Timer1.Stop()
                Timer2.Stop()
                Timer3.Stop()

                SINGE.Location = New Point(SINGE.Location.X - 5, SINGE.Location.Y)
                Timer4.Start()
        End Select
    End Sub

    Private Sub FormCHASSE_KeyUp(sender As Object, e As KeyEventArgs) Handles MyBase.KeyUp
        Select Case e.KeyCode
            Case Keys.W
                Timer1.Stop()
                SINGE.Image = My.Resources.stand
            Case Keys.S
                Timer2.Stop()
                SINGE.Image = My.Resources.stand

            Case Keys.D
                Timer3.Stop()
                SINGE.Image = My.Resources.stand

            Case Keys.A
                Timer4.Stop()
                SINGE.Image = My.Resources.stand

        End Select
    End Sub
End Class