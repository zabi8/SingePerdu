﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Formmonster
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Formmonster))
        Me.SINGE = New System.Windows.Forms.PictureBox()
        Me.M7 = New System.Windows.Forms.PictureBox()
        Me.M8 = New System.Windows.Forms.PictureBox()
        Me.M1 = New System.Windows.Forms.PictureBox()
        Me.M2 = New System.Windows.Forms.PictureBox()
        Me.M3 = New System.Windows.Forms.PictureBox()
        Me.M4 = New System.Windows.Forms.PictureBox()
        Me.M5 = New System.Windows.Forms.PictureBox()
        Me.M6 = New System.Windows.Forms.PictureBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        CType(Me.SINGE, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.M7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.M8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.M1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.M2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.M3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.M4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.M5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.M6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SINGE
        '
        Me.SINGE.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.SINGE.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.stand
        Me.SINGE.Location = New System.Drawing.Point(263, 137)
        Me.SINGE.Name = "SINGE"
        Me.SINGE.Size = New System.Drawing.Size(26, 31)
        Me.SINGE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.SINGE.TabIndex = 0
        Me.SINGE.TabStop = False
        '
        'M7
        '
        Me.M7.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.M7.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.monster
        Me.M7.Location = New System.Drawing.Point(42, 105)
        Me.M7.Name = "M7"
        Me.M7.Size = New System.Drawing.Size(33, 31)
        Me.M7.TabIndex = 1
        Me.M7.TabStop = False
        '
        'M8
        '
        Me.M8.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.M8.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.monster
        Me.M8.Location = New System.Drawing.Point(81, 12)
        Me.M8.Name = "M8"
        Me.M8.Size = New System.Drawing.Size(33, 31)
        Me.M8.TabIndex = 2
        Me.M8.TabStop = False
        '
        'M1
        '
        Me.M1.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.M1.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.monster
        Me.M1.Location = New System.Drawing.Point(228, 2)
        Me.M1.Name = "M1"
        Me.M1.Size = New System.Drawing.Size(33, 31)
        Me.M1.TabIndex = 3
        Me.M1.TabStop = False
        '
        'M2
        '
        Me.M2.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.M2.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.monster
        Me.M2.Location = New System.Drawing.Point(405, 12)
        Me.M2.Name = "M2"
        Me.M2.Size = New System.Drawing.Size(33, 31)
        Me.M2.TabIndex = 4
        Me.M2.TabStop = False
        '
        'M3
        '
        Me.M3.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.M3.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.monster
        Me.M3.Location = New System.Drawing.Point(470, 137)
        Me.M3.Name = "M3"
        Me.M3.Size = New System.Drawing.Size(33, 31)
        Me.M3.TabIndex = 5
        Me.M3.TabStop = False
        '
        'M4
        '
        Me.M4.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.M4.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.monster
        Me.M4.Location = New System.Drawing.Point(460, 247)
        Me.M4.Name = "M4"
        Me.M4.Size = New System.Drawing.Size(33, 31)
        Me.M4.TabIndex = 6
        Me.M4.TabStop = False
        '
        'M5
        '
        Me.M5.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.M5.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.monster
        Me.M5.Location = New System.Drawing.Point(256, 256)
        Me.M5.Name = "M5"
        Me.M5.Size = New System.Drawing.Size(33, 31)
        Me.M5.TabIndex = 7
        Me.M5.TabStop = False
        '
        'M6
        '
        Me.M6.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.M6.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.monster
        Me.M6.Location = New System.Drawing.Point(99, 237)
        Me.M6.Name = "M6"
        Me.M6.Size = New System.Drawing.Size(33, 31)
        Me.M6.TabIndex = 8
        Me.M6.TabStop = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 1
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(542, 285)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 9
        Me.PictureBox1.TabStop = False
        Me.PictureBox1.Visible = False
        '
        'Timer2
        '
        Me.Timer2.Interval = 13000
        '
        'Formmonster
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(543, 290)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.M6)
        Me.Controls.Add(Me.M5)
        Me.Controls.Add(Me.M4)
        Me.Controls.Add(Me.M3)
        Me.Controls.Add(Me.M2)
        Me.Controls.Add(Me.M1)
        Me.Controls.Add(Me.M8)
        Me.Controls.Add(Me.M7)
        Me.Controls.Add(Me.SINGE)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "Formmonster"
        Me.Text = "SINGE PERDU"
        CType(Me.SINGE, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.M7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.M8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.M1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.M2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.M3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.M4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.M5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.M6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents SINGE As PictureBox
    Friend WithEvents M7 As PictureBox
    Friend WithEvents M8 As PictureBox
    Friend WithEvents M1 As PictureBox
    Friend WithEvents M2 As PictureBox
    Friend WithEvents M3 As PictureBox
    Friend WithEvents M4 As PictureBox
    Friend WithEvents M5 As PictureBox
    Friend WithEvents M6 As PictureBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Timer2 As Timer
End Class
