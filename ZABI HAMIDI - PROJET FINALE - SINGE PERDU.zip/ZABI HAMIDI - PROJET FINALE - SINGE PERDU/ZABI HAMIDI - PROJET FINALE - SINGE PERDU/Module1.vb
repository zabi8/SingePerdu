﻿Module Module1
    Public game1 As Integer = 1
    Public game2 As Integer = 1
    Public game3 As Integer = 1
    Public game4 As Integer = 1
    Public gametotal As Integer = 0

End Module
