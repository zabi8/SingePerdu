﻿Public Class FormTROUVE
    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Me.Dispose()
        gametotal += 1
        If Not gametotal = 4 Then
            game3 = 2
            MsgBox(Title:="MISSION ACCOMPLI", Prompt:="BRAVO! VOUS AVEZ TROUVEZ LA BANANE!")
            MsgBox(Title:="MISSION ACCOMPLI", Prompt:="IL VOUS RESTE " & 4 - gametotal & " MISSIONS!")
            Form6.Visible = True
        End If

    End Sub

    Private Sub FormTROUVE_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Form6.Visible = False
    End Sub
End Class