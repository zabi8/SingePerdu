﻿Public Class Formmonster
    Dim x As Integer = 0
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        If M1.Top > SINGE.Top Then
            M1.Location = New Point(M1.Location.X, M1.Location.Y - 1)
        End If
        If M1.Left > SINGE.Left Then
            M1.Location = New Point(M1.Location.X - 1, M1.Location.Y)
        End If
        If M1.Top < SINGE.Top Then
            M1.Location = New Point(M1.Location.X, M1.Location.Y + 1)
        End If
        If M1.Left < SINGE.Left Then
            M1.Location = New Point(M1.Location.X + 1, M1.Location.Y)
        End If

        If M2.Top > SINGE.Top Then
            M2.Location = New Point(M2.Location.X, M2.Location.Y - 1)
        End If
        If M2.Left > SINGE.Left Then
            M2.Location = New Point(M2.Location.X - 1, M2.Location.Y)
        End If
        If M2.Top < SINGE.Top Then
            M2.Location = New Point(M2.Location.X, M2.Location.Y + 1)
        End If
        If M2.Left < SINGE.Left Then
            M2.Location = New Point(M2.Location.X + 1, M2.Location.Y)
        End If

        If M3.Top > SINGE.Top Then
            M3.Location = New Point(M3.Location.X, M3.Location.Y - 1)
        End If
        If M3.Left > SINGE.Left Then
            M3.Location = New Point(M3.Location.X - 1, M3.Location.Y)
        End If
        If M3.Top < SINGE.Top Then
            M3.Location = New Point(M3.Location.X, M3.Location.Y + 1)
        End If
        If M3.Left < SINGE.Left Then
            M3.Location = New Point(M3.Location.X + 1, M3.Location.Y)
        End If

        If M4.Top > SINGE.Top Then
            M4.Location = New Point(M4.Location.X, M4.Location.Y - 1)
        End If
        If M4.Left > SINGE.Left Then
            M4.Location = New Point(M4.Location.X - 1, M4.Location.Y)
        End If
        If M4.Top < SINGE.Top Then
            M4.Location = New Point(M4.Location.X, M4.Location.Y + 1)
        End If
        If M4.Left < SINGE.Left Then
            M4.Location = New Point(M4.Location.X + 1, M4.Location.Y)
        End If

        If M5.Top > SINGE.Top Then
            M5.Location = New Point(M5.Location.X, M5.Location.Y - 1)
        End If
        If M5.Left > SINGE.Left Then
            M5.Location = New Point(M5.Location.X - 1, M5.Location.Y)
        End If
        If M5.Top < SINGE.Top Then
            M5.Location = New Point(M5.Location.X, M5.Location.Y + 1)
        End If
        If M5.Left < SINGE.Left Then
            M5.Location = New Point(M5.Location.X + 1, M5.Location.Y)
        End If

        If M6.Top > SINGE.Top Then
            M6.Location = New Point(M6.Location.X, M6.Location.Y - 1)
        End If
        If M6.Left > SINGE.Left Then
            M6.Location = New Point(M6.Location.X - 1, M6.Location.Y)
        End If
        If M6.Top < SINGE.Top Then
            M6.Location = New Point(M6.Location.X, M6.Location.Y + 1)
        End If
        If M6.Left < SINGE.Left Then
            M6.Location = New Point(M6.Location.X + 1, M6.Location.Y)
        End If

        If M7.Top > SINGE.Top Then
            M7.Location = New Point(M7.Location.X, M7.Location.Y - 1)
        End If
        If M7.Left > SINGE.Left Then
            M7.Location = New Point(M7.Location.X - 1, M7.Location.Y)
        End If
        If M7.Top < SINGE.Top Then
            M7.Location = New Point(M7.Location.X, M7.Location.Y + 1)
        End If
        If M7.Left < SINGE.Left Then
            M7.Location = New Point(M7.Location.X + 1, M7.Location.Y)
        End If

        If M8.Top > SINGE.Top Then
            M8.Location = New Point(M8.Location.X, M8.Location.Y - 1)
        End If
        If M8.Left > SINGE.Left Then
            M8.Location = New Point(M8.Location.X - 1, M8.Location.Y)
        End If
        If M8.Top < SINGE.Top Then
            M8.Location = New Point(M8.Location.X, M8.Location.Y + 1)
        End If
        If M8.Left < SINGE.Left Then
            M8.Location = New Point(M8.Location.X + 1, M8.Location.Y)
        End If

        If M1.Bounds.IntersectsWith(SINGE.Bounds) Then
            Timer1.Stop()
            MsgBox(Title:="PERDANT", Prompt:="UN MONSTRE VOUS AVEZ MANGÉ")
            Dim formmonster As New Formmonster
            Me.Dispose()
            Form5.Visible = True
        End If

        If M2.Bounds.IntersectsWith(SINGE.Bounds) Then
            Timer1.Stop()
            MsgBox(Title:="PERDANT", Prompt:="UN MONSTRE VOUS AVEZ MANGÉ")
            Dim formmonster As New Formmonster
            Me.Dispose()
            Form5.Visible = True
        End If

        If M3.Bounds.IntersectsWith(SINGE.Bounds) Then
            Timer1.Stop()
            MsgBox(Title:="PERDANT", Prompt:="UN MONSTRE VOUS AVEZ MANGÉ")
            Dim formmonster As New Formmonster
            Me.Dispose()
            Form5.Visible = True
        End If

        If M4.Bounds.IntersectsWith(SINGE.Bounds) Then
            Timer1.Stop()
            MsgBox(Title:="PERDANT", Prompt:="UN MONSTRE VOUS AVEZ MANGÉ")
            Dim formmonster As New Formmonster
            Me.Dispose()
            Form5.Visible = True
        End If

        If M5.Bounds.IntersectsWith(SINGE.Bounds) Then
            Timer1.Stop()
            MsgBox(Title:="PERDANT", Prompt:="UN MONSTRE VOUS AVEZ MANGÉ")
            Dim formmonster As New Formmonster
            Me.Dispose()
            Form5.Visible = True
        End If

        If M6.Bounds.IntersectsWith(SINGE.Bounds) Then
            Timer1.Stop()
            MsgBox(Title:="PERDANT", Prompt:="UN MONSTRE VOUS AVEZ MANGÉ")
            Dim formmonster As New Formmonster
            Me.Dispose()
            Form5.Visible = True
        End If

        If M7.Bounds.IntersectsWith(SINGE.Bounds) Then
            Timer1.Stop()
            MsgBox(Title:="PERDANT", Prompt:="UN MONSTRE VOUS AVEZ MANGÉ")
            Dim formmonster As New Formmonster
            Me.Dispose()
            Form5.Visible = True
        End If

        If M8.Bounds.IntersectsWith(SINGE.Bounds) Then
            Timer1.Stop()
            MsgBox(Title:="PERDANT", Prompt:="UN MONSTRE VOUS AVEZ MANGÉ")
            Dim formmonster As New Formmonster
            Me.Dispose()
            Form5.Visible = True
        End If

        If x = 8 Then
            Timer1.Stop()
            MsgBox(Title:="MONSTRE = MORT B)", Prompt:="BRAVO")
            SINGE.Visible = False
            PictureBox1.Visible = True
            Timer2.Start()
        End If

    End Sub


    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Form5.Visible = False
        Timer1.Start()
    End Sub

    Private Sub M1_Click(sender As Object, e As EventArgs) Handles M1.Click
        M1.Top = 50000
        x += 1
    End Sub

    Private Sub M2_Click(sender As Object, e As EventArgs) Handles M2.Click
        M2.Top = 50000
        x += 1
    End Sub

    Private Sub M3_Click(sender As Object, e As EventArgs) Handles M3.Click
        M3.Top = 50000
        x += 1
    End Sub

    Private Sub M4_Click(sender As Object, e As EventArgs) Handles M4.Click
        M4.Top = 50000
        x += 1
    End Sub

    Private Sub M5_Click(sender As Object, e As EventArgs) Handles M5.Click
        M5.Top = 50000
        x += 1
    End Sub

    Private Sub M6_Click(sender As Object, e As EventArgs) Handles M6.Click
        M6.Top = 50000
        x += 1
    End Sub

    Private Sub M7_Click(sender As Object, e As EventArgs) Handles M7.Click
        M7.Top = 50000
        x += 1
    End Sub

    Private Sub M8_Click(sender As Object, e As EventArgs) Handles M8.Click
        M8.Top = 50000
        x += 1
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        x = 9
        Form6.Visible = True
        Timer2.Stop()
    End Sub
End Class