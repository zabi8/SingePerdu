﻿Public Class FormQUESTIONNAIRE
    Private Sub FormQUESTIONNAIRE_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Form6.Visible = False
        Dim x As String = ""
        Do Until x = "zabi"
            x = InputBox(Title:="MISSION ACCOMPLI", Prompt:="QUI EST VOTRE ELEVE PREFEREE?")
            If x.ToLower = "zabi" Then
                x = x.ToLower
                MsgBox(Title:="QUESTIONNAIRE", Prompt:="BRAVO!")
                gametotal += 1
                If Not gametotal = 4 Then
                    game2 = 2
                    MsgBox(Title:="MISSION ACCOMPLI", Prompt:="IL VOUS RESTE " & 4 - gametotal & " MISSIONS!")
                    Me.Dispose()
                    Form6.Visible = True
                End If
            Else
                    MsgBox(Title:=":/", Prompt:="MAUVAISE REPONSE")
            End If
        Loop
    End Sub
End Class