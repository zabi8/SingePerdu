﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Formcave
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Formcave))
        Me.ro2 = New System.Windows.Forms.PictureBox()
        Me.ro1 = New System.Windows.Forms.PictureBox()
        Me.ro3 = New System.Windows.Forms.PictureBox()
        Me.ro4 = New System.Windows.Forms.PictureBox()
        Me.ro5 = New System.Windows.Forms.PictureBox()
        Me.ro6 = New System.Windows.Forms.PictureBox()
        Me.ro7 = New System.Windows.Forms.PictureBox()
        Me.Player = New System.Windows.Forms.PictureBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer4 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer5 = New System.Windows.Forms.Timer(Me.components)
        Me.lblattention = New System.Windows.Forms.Label()
        Me.Timer6 = New System.Windows.Forms.Timer(Me.components)
        Me.hole = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Timer7 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer8 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer9 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer10 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer11 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer12 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer13 = New System.Windows.Forms.Timer(Me.components)
        Me.Label4 = New System.Windows.Forms.Label()
        Me.WALLDOWN = New System.Windows.Forms.Label()
        Me.WALLUP = New System.Windows.Forms.Label()
        Me.WALLLEFT = New System.Windows.Forms.Label()
        Me.WALLRIGHT = New System.Windows.Forms.Label()
        CType(Me.ro2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ro1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ro3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ro4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ro5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ro6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ro7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Player, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.hole, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ro2
        '
        Me.ro2.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.r2
        Me.ro2.Location = New System.Drawing.Point(212, 0)
        Me.ro2.Name = "ro2"
        Me.ro2.Size = New System.Drawing.Size(35, 29)
        Me.ro2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ro2.TabIndex = 0
        Me.ro2.TabStop = False
        '
        'ro1
        '
        Me.ro1.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.r1
        Me.ro1.Location = New System.Drawing.Point(145, 0)
        Me.ro1.Name = "ro1"
        Me.ro1.Size = New System.Drawing.Size(35, 29)
        Me.ro1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ro1.TabIndex = 1
        Me.ro1.TabStop = False
        '
        'ro3
        '
        Me.ro3.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.r3
        Me.ro3.Location = New System.Drawing.Point(294, 0)
        Me.ro3.Name = "ro3"
        Me.ro3.Size = New System.Drawing.Size(35, 29)
        Me.ro3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ro3.TabIndex = 1
        Me.ro3.TabStop = False
        '
        'ro4
        '
        Me.ro4.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.r3
        Me.ro4.Location = New System.Drawing.Point(369, 0)
        Me.ro4.Name = "ro4"
        Me.ro4.Size = New System.Drawing.Size(35, 29)
        Me.ro4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ro4.TabIndex = 2
        Me.ro4.TabStop = False
        '
        'ro5
        '
        Me.ro5.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.r4
        Me.ro5.Location = New System.Drawing.Point(442, 0)
        Me.ro5.Name = "ro5"
        Me.ro5.Size = New System.Drawing.Size(35, 29)
        Me.ro5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ro5.TabIndex = 3
        Me.ro5.TabStop = False
        '
        'ro6
        '
        Me.ro6.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.r1
        Me.ro6.Location = New System.Drawing.Point(532, 0)
        Me.ro6.Name = "ro6"
        Me.ro6.Size = New System.Drawing.Size(35, 29)
        Me.ro6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ro6.TabIndex = 4
        Me.ro6.TabStop = False
        '
        'ro7
        '
        Me.ro7.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.r2
        Me.ro7.Location = New System.Drawing.Point(605, 0)
        Me.ro7.Name = "ro7"
        Me.ro7.Size = New System.Drawing.Size(35, 29)
        Me.ro7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ro7.TabIndex = 5
        Me.ro7.TabStop = False
        '
        'Player
        '
        Me.Player.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.Player.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Player.Image = CType(resources.GetObject("Player.Image"), System.Drawing.Image)
        Me.Player.Location = New System.Drawing.Point(44, 217)
        Me.Player.Name = "Player"
        Me.Player.Size = New System.Drawing.Size(34, 39)
        Me.Player.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Player.TabIndex = 6
        Me.Player.TabStop = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 400
        '
        'Timer2
        '
        Me.Timer2.Interval = 400
        '
        'Timer3
        '
        Me.Timer3.Interval = 400
        '
        'Timer4
        '
        Me.Timer4.Interval = 400
        '
        'Timer5
        '
        Me.Timer5.Interval = 1
        '
        'lblattention
        '
        Me.lblattention.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblattention.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.lblattention.Location = New System.Drawing.Point(207, 88)
        Me.lblattention.Name = "lblattention"
        Me.lblattention.Size = New System.Drawing.Size(385, 93)
        Me.lblattention.TabIndex = 7
        Me.lblattention.Text = "FAIT ATTENTION AUX ROCHES."
        '
        'Timer6
        '
        Me.Timer6.Interval = 2000
        '
        'hole
        '
        Me.hole.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.hole.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.hole
        Me.hole.Location = New System.Drawing.Point(727, 178)
        Me.hole.Name = "hole"
        Me.hole.Size = New System.Drawing.Size(35, 29)
        Me.hole.TabIndex = 8
        Me.hole.TabStop = False
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Location = New System.Drawing.Point(716, 140)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 10)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Label1"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Location = New System.Drawing.Point(738, 88)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(13, 87)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Label2"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label3.Location = New System.Drawing.Point(727, 150)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(35, 13)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Label3"
        '
        'Timer7
        '
        '
        'Timer8
        '
        '
        'Timer9
        '
        '
        'Timer10
        '
        '
        'Timer11
        '
        '
        'Timer12
        '
        '
        'Timer13
        '
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.Label4.Location = New System.Drawing.Point(12, 388)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(192, 53)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "WASD POUR BOUGER"
        '
        'WALLDOWN
        '
        Me.WALLDOWN.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.WALLDOWN.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.WALLDOWN.Location = New System.Drawing.Point(-4, 444)
        Me.WALLDOWN.Name = "WALLDOWN"
        Me.WALLDOWN.Size = New System.Drawing.Size(804, 251)
        Me.WALLDOWN.TabIndex = 13
        '
        'WALLUP
        '
        Me.WALLUP.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.WALLUP.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.WALLUP.Location = New System.Drawing.Point(-4, -131)
        Me.WALLUP.Name = "WALLUP"
        Me.WALLUP.Size = New System.Drawing.Size(804, 141)
        Me.WALLUP.TabIndex = 14
        '
        'WALLLEFT
        '
        Me.WALLLEFT.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.WALLLEFT.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.WALLLEFT.Location = New System.Drawing.Point(-53, 10)
        Me.WALLLEFT.Name = "WALLLEFT"
        Me.WALLLEFT.Size = New System.Drawing.Size(61, 434)
        Me.WALLLEFT.TabIndex = 15
        '
        'WALLRIGHT
        '
        Me.WALLRIGHT.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.WALLRIGHT.Image = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.WALLRIGHT.Location = New System.Drawing.Point(790, 10)
        Me.WALLRIGHT.Name = "WALLRIGHT"
        Me.WALLRIGHT.Size = New System.Drawing.Size(433, 434)
        Me.WALLRIGHT.TabIndex = 16
        '
        'Formcave
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.ZABI_HAMIDI___PROJET_FINALE___SINGE_PERDU.My.Resources.Resources.paper
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.WALLRIGHT)
        Me.Controls.Add(Me.WALLLEFT)
        Me.Controls.Add(Me.WALLUP)
        Me.Controls.Add(Me.WALLDOWN)
        Me.Controls.Add(Me.Player)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.hole)
        Me.Controls.Add(Me.lblattention)
        Me.Controls.Add(Me.ro7)
        Me.Controls.Add(Me.ro6)
        Me.Controls.Add(Me.ro5)
        Me.Controls.Add(Me.ro4)
        Me.Controls.Add(Me.ro3)
        Me.Controls.Add(Me.ro1)
        Me.Controls.Add(Me.ro2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "Formcave"
        Me.Text = "SINGE PERDU"
        CType(Me.ro2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ro1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ro3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ro4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ro5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ro6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ro7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Player, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.hole, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ro2 As PictureBox
    Friend WithEvents ro1 As PictureBox
    Friend WithEvents ro3 As PictureBox
    Friend WithEvents ro4 As PictureBox
    Friend WithEvents ro5 As PictureBox
    Friend WithEvents ro6 As PictureBox
    Friend WithEvents ro7 As PictureBox
    Friend WithEvents Player As PictureBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Timer3 As Timer
    Friend WithEvents Timer4 As Timer
    Friend WithEvents Timer5 As Timer
    Friend WithEvents lblattention As Label
    Friend WithEvents Timer6 As Timer
    Friend WithEvents hole As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Timer7 As Timer
    Friend WithEvents Timer8 As Timer
    Friend WithEvents Timer9 As Timer
    Friend WithEvents Timer10 As Timer
    Friend WithEvents Timer11 As Timer
    Friend WithEvents Timer12 As Timer
    Friend WithEvents Timer13 As Timer
    Friend WithEvents Label4 As Label
    Friend WithEvents WALLDOWN As Label
    Friend WithEvents WALLUP As Label
    Friend WithEvents WALLLEFT As Label
    Friend WithEvents WALLRIGHT As Label
End Class
