﻿Public Class FormEND
    Private Sub FormEND_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Form6.Visible = False
        MsgBox(Title:="FIN", Prompt:="BRAVO VOUS AVEZ SAUVER TA FAMILLE!")
        MsgBox(Title:="FIN", Prompt:="MAIS QUELQUE CHOSES C'EST PASSÉ")
        MsgBox(Title:="FIN", Prompt:="...")
        Timer1.Start()
        Button1.Visible = False
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Button1.Visible = True
        PictureBox1.Image = My.Resources.FIN
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        End
    End Sub
End Class