﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        PictureBox1.Visible = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnstart.Click
        btnstart.Enabled = False
        PictureBox1.Visible = True
        timer1.Start()
    End Sub


    Private Sub timer1_Tick(sender As Object, e As EventArgs) Handles timer1.Tick
        Form2.Visible = True
        timer1.Stop()
    End Sub
End Class
