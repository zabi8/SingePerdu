﻿Public Class Formcave

    Private Sub Formcave_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        Select Case e.KeyCode
            Case Keys.W
                Timer2.Stop()
                Timer3.Stop()
                Timer4.Stop()
                Player.Location = New Point(Player.Location.X, Player.Location.Y - 5)
                Timer1.Start()
            Case Keys.S
                Timer1.Stop()
                Timer3.Stop()
                Timer4.Stop()
                Player.Location = New Point(Player.Location.X, Player.Location.Y + 5)
                Timer2.Start()
            Case Keys.D
                Timer1.Stop()
                Timer2.Stop()
                Timer4.Stop()

                Player.Location = New Point(Player.Location.X + 5, Player.Location.Y)
                Timer3.Start()
            Case Keys.A
                Timer1.Stop()
                Timer2.Stop()
                Timer3.Stop()

                Player.Location = New Point(Player.Location.X - 5, Player.Location.Y)
                Timer4.Start()
        End Select
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Player.Image = My.Resources.goingup
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Player.Image = My.Resources.goingdown

    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        Player.Image = My.Resources.rightrun

    End Sub

    Private Sub Timer4_Tick(sender As Object, e As EventArgs) Handles Timer4.Tick
        Player.Image = My.Resources.leftrun

    End Sub

    Private Sub Timer5_Tick(sender As Object, e As EventArgs) Handles Timer5.Tick
        If Player.Bounds.IntersectsWith(WALLDOWN.Bounds) Then
            Player.Location = New Point(Player.Location.X, Player.Location.Y - 5)
        End If
        If Player.Bounds.IntersectsWith(WALLUP.Bounds) Then
            Player.Location = New Point(Player.Location.X, Player.Location.Y + 5)
        End If
        If Player.Bounds.IntersectsWith(WALLRIGHT.Bounds) Then
            Player.Location = New Point(Player.Location.X - 5, Player.Location.Y)
        End If
        If Player.Bounds.IntersectsWith(WALLLEFT.Bounds) Then
            Player.Location = New Point(Player.Location.X + 5, Player.Location.Y)
        End If
        If ro1.Top >= 450 Then
            ro1.Top = 0
        End If
        If ro2.Top >= 450 Then
            ro2.Top = 0
        End If
        If ro3.Top >= 450 Then
            ro3.Top = 0
        End If
        If ro4.Top >= 450 Then
            ro4.Top = 0
        End If
        If ro5.Top >= 450 Then
            ro5.Top = 0
        End If
        If ro6.Top >= 450 Then
            ro6.Top = 0
        End If
        If ro7.Top >= 450 Then
            ro7.Top = 0
        End If

        If Player.Bounds.IntersectsWith(ro1.Bounds) Then
            Player.Location = New Point(Player.Location.X = 44, Player.Location.Y = 217)
        End If
        If Player.Bounds.IntersectsWith(ro2.Bounds) Then
            Player.Location = New Point(Player.Location.X = 44, Player.Location.Y = 217)
        End If
        If Player.Bounds.IntersectsWith(ro3.Bounds) Then
            Player.Location = New Point(Player.Location.X = 44, Player.Location.Y = 217)
        End If
        If Player.Bounds.IntersectsWith(ro4.Bounds) Then
            Player.Location = New Point(Player.Location.X = 44, Player.Location.Y = 217)
        End If
        If Player.Bounds.IntersectsWith(ro5.Bounds) Then
            Player.Location = New Point(Player.Location.X = 44, Player.Location.Y = 217)
        End If
        If Player.Bounds.IntersectsWith(ro6.Bounds) Then
            Player.Location = New Point(Player.Location.X = 44, Player.Location.Y = 217)
        End If
        If Player.Bounds.IntersectsWith(ro7.Bounds) Then
            Player.Location = New Point(Player.Location.X = 44, Player.Location.Y = 217)
        End If
        If Player.Bounds.IntersectsWith(hole.Bounds) Then
            Form5.Visible = True
            Timer5.Stop()
        End If
    End Sub

    Private Sub Formcave_KeyUp(sender As Object, e As KeyEventArgs) Handles MyBase.KeyUp
        Select Case e.KeyCode
            Case Keys.W
                Timer1.Stop()
                Player.Image = My.Resources.stand
            Case Keys.S
                Timer2.Stop()
                Player.Image = My.Resources.stand

            Case Keys.D
                Timer3.Stop()
                Player.Image = My.Resources.stand

            Case Keys.A
                Timer4.Stop()
                Player.Image = My.Resources.stand

        End Select
    End Sub

    Private Sub Timer6_Tick(sender As Object, e As EventArgs) Handles Timer6.Tick
        lblattention.Visible = False
    End Sub

    Private Sub Timer7_Tick(sender As Object, e As EventArgs) Handles Timer7.Tick
        ro1.Location = New Point(ro1.Location.X, ro1.Location.Y + 10)
    End Sub
    Private Sub Timer8_Tick(sender As Object, e As EventArgs) Handles Timer8.Tick
        ro2.Location = New Point(ro2.Location.X, ro2.Location.Y + 15)
    End Sub
    Private Sub Timer9_Tick(sender As Object, e As EventArgs) Handles Timer9.Tick
        ro3.Location = New Point(ro3.Location.X, ro3.Location.Y + 8)
    End Sub
    Private Sub Timer10_Tick(sender As Object, e As EventArgs) Handles Timer10.Tick
        ro4.Location = New Point(ro4.Location.X, ro4.Location.Y + 34)
    End Sub
    Private Sub Timer11_Tick(sender As Object, e As EventArgs) Handles Timer11.Tick
        ro5.Location = New Point(ro5.Location.X, ro5.Location.Y + 6)
    End Sub
    Private Sub Timer12_Tick(sender As Object, e As EventArgs) Handles Timer12.Tick
        ro6.Location = New Point(ro6.Location.X, ro6.Location.Y + 80)
    End Sub
    Private Sub Timer13_Tick(sender As Object, e As EventArgs) Handles Timer13.Tick
        ro7.Location = New Point(ro7.Location.X, ro7.Location.Y + 12)
    End Sub

    Private Sub Formcave_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Form2.Visible = False
        Timer5.Start()
        Timer6.Start()
        Timer7.Start()
        Timer8.Start()
        Timer9.Start()
        Timer10.Start()
        Timer11.Start()
        Timer12.Start()
        Timer13.Start()
    End Sub
End Class