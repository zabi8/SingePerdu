﻿Public Class FormCORRIGER
    Dim selection As Point
    Dim x As Integer = 0
    Private Sub FormCORRIGER_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Form6.Visible = False
        Timer1.Start()
    End Sub

    Private Sub an1_MouseMove(sender As Object, e As MouseEventArgs) Handles an1.MouseMove
        Static UpdateMouseOnNextMove As Boolean = False
        If DirectCast(e, MouseEventArgs).Button = MouseButtons.Left Then

            If UpdateMouseOnNextMove Then
                an1.Left += (Windows.Forms.Cursor.Position.X - selection.X)
                an1.Top += (Windows.Forms.Cursor.Position.Y - selection.Y)
                Windows.Forms.Cursor.Position = selection
                UpdateMouseOnNextMove = False
            Else
                UpdateMouseOnNextMove = True
            End If
        Else
            selection = Windows.Forms.Cursor.Position
        End If
    End Sub


    Private Sub an2_MouseMove(sender As Object, e As MouseEventArgs) Handles an2.MouseMove
        Static UpdateMouseOnNextMove As Boolean = False
        If DirectCast(e, MouseEventArgs).Button = MouseButtons.Left Then

            If UpdateMouseOnNextMove Then
                an2.Left += (Windows.Forms.Cursor.Position.X - selection.X)
                an2.Top += (Windows.Forms.Cursor.Position.Y - selection.Y)
                Windows.Forms.Cursor.Position = selection
                UpdateMouseOnNextMove = False
            Else
                UpdateMouseOnNextMove = True
            End If
        Else
            selection = Windows.Forms.Cursor.Position
        End If
    End Sub

    Private Sub an3_MouseMove(sender As Object, e As MouseEventArgs) Handles an3.MouseMove
        Static UpdateMouseOnNextMove As Boolean = False
        If DirectCast(e, MouseEventArgs).Button = MouseButtons.Left Then

            If UpdateMouseOnNextMove Then
                an3.Left += (Windows.Forms.Cursor.Position.X - selection.X)
                an3.Top += (Windows.Forms.Cursor.Position.Y - selection.Y)
                Windows.Forms.Cursor.Position = selection
                UpdateMouseOnNextMove = False
            Else
                UpdateMouseOnNextMove = True
            End If
        Else
            selection = Windows.Forms.Cursor.Position
        End If
    End Sub

    Private Sub an4_MouseMove(sender As Object, e As MouseEventArgs) Handles an4.MouseMove
        Static UpdateMouseOnNextMove As Boolean = False
        If DirectCast(e, MouseEventArgs).Button = MouseButtons.Left Then

            If UpdateMouseOnNextMove Then
                an4.Left += (Windows.Forms.Cursor.Position.X - selection.X)
                an4.Top += (Windows.Forms.Cursor.Position.Y - selection.Y)
                Windows.Forms.Cursor.Position = selection
                UpdateMouseOnNextMove = False
            Else
                UpdateMouseOnNextMove = True
            End If
        Else
            selection = Windows.Forms.Cursor.Position
        End If
    End Sub

    Private Sub an5_MouseMove(sender As Object, e As MouseEventArgs) Handles an5.MouseMove
        Static UpdateMouseOnNextMove As Boolean = False
        If DirectCast(e, MouseEventArgs).Button = MouseButtons.Left Then

            If UpdateMouseOnNextMove Then
                an5.Left += (Windows.Forms.Cursor.Position.X - selection.X)
                an5.Top += (Windows.Forms.Cursor.Position.Y - selection.Y)
                Windows.Forms.Cursor.Position = selection
                UpdateMouseOnNextMove = False
            Else
                UpdateMouseOnNextMove = True
            End If
        Else
            selection = Windows.Forms.Cursor.Position
        End If
    End Sub

    Private Sub an6_MouseMove(sender As Object, e As MouseEventArgs) Handles an6.MouseMove
        Static UpdateMouseOnNextMove As Boolean = False
        If DirectCast(e, MouseEventArgs).Button = MouseButtons.Left Then

            If UpdateMouseOnNextMove Then
                an6.Left += (Windows.Forms.Cursor.Position.X - selection.X)
                an6.Top += (Windows.Forms.Cursor.Position.Y - selection.Y)
                Windows.Forms.Cursor.Position = selection
                UpdateMouseOnNextMove = False
            Else
                UpdateMouseOnNextMove = True
            End If
        Else
            selection = Windows.Forms.Cursor.Position
        End If
    End Sub

    Private Sub an7_MouseMove(sender As Object, e As MouseEventArgs) Handles an7.MouseMove
        Static UpdateMouseOnNextMove As Boolean = False
        If DirectCast(e, MouseEventArgs).Button = MouseButtons.Left Then

            If UpdateMouseOnNextMove Then
                an7.Left += (Windows.Forms.Cursor.Position.X - selection.X)
                an7.Top += (Windows.Forms.Cursor.Position.Y - selection.Y)
                Windows.Forms.Cursor.Position = selection
                UpdateMouseOnNextMove = False
            Else
                UpdateMouseOnNextMove = True
            End If
        Else
            selection = Windows.Forms.Cursor.Position
        End If
    End Sub

    Private Sub an8_MouseMove(sender As Object, e As MouseEventArgs) Handles an8.MouseMove
        Static UpdateMouseOnNextMove As Boolean = False
        If DirectCast(e, MouseEventArgs).Button = MouseButtons.Left Then

            If UpdateMouseOnNextMove Then
                an8.Left += (Windows.Forms.Cursor.Position.X - selection.X)
                an8.Top += (Windows.Forms.Cursor.Position.Y - selection.Y)
                Windows.Forms.Cursor.Position = selection
                UpdateMouseOnNextMove = False
            Else
                UpdateMouseOnNextMove = True
            End If
        Else
            selection = Windows.Forms.Cursor.Position
        End If
    End Sub

    Private Sub an9_MouseMove(sender As Object, e As MouseEventArgs) Handles an9.MouseMove
        Static UpdateMouseOnNextMove As Boolean = False
        If DirectCast(e, MouseEventArgs).Button = MouseButtons.Left Then

            If UpdateMouseOnNextMove Then
                an9.Left += (Windows.Forms.Cursor.Position.X - selection.X)
                an9.Top += (Windows.Forms.Cursor.Position.Y - selection.Y)
                Windows.Forms.Cursor.Position = selection
                UpdateMouseOnNextMove = False
            Else
                UpdateMouseOnNextMove = True
            End If
        Else
            selection = Windows.Forms.Cursor.Position
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If an1.Bounds.IntersectsWith(PictureBox1.Bounds) Then
            PictureBox1.Image = My.Resources.gg1
            an1.Visible = False
            an1.Location = New Point(an1.Location.X + 1000, an1.Location.Y + 1000)
            x += 1
        End If
        If an2.Bounds.IntersectsWith(PictureBox2.Bounds) Then
            PictureBox2.Image = My.Resources.gg2
            an2.Visible = False
            an2.Location = New Point(an2.Location.X + 1000, an2.Location.Y + 1000)
            x += 1
        End If
        If an3.Bounds.IntersectsWith(PictureBox3.Bounds) Then
            PictureBox3.Image = My.Resources.gg3
            an3.Visible = False
            an3.Location = New Point(an3.Location.X + 1000, an3.Location.Y + 1000)
            x += 1
        End If
        If an4.Bounds.IntersectsWith(PictureBox4.Bounds) Then
            PictureBox4.Image = My.Resources.gg4
            an4.Visible = False
            an4.Location = New Point(an4.Location.X + 1000, an4.Location.Y + 1000)
            x += 1
        End If
        If an5.Bounds.IntersectsWith(PictureBox5.Bounds) Then
            PictureBox5.Image = My.Resources.gg5
            an5.Visible = False
            an5.Location = New Point(an5.Location.X + 1000, an5.Location.Y + 1000)
            x += 1
        End If
        If an6.Bounds.IntersectsWith(PictureBox6.Bounds) Then
            PictureBox6.Image = My.Resources.gg6
            an6.Visible = False
            an6.Location = New Point(an6.Location.X + 1000, an6.Location.Y + 1000)
            x += 1
        End If
        If an7.Bounds.IntersectsWith(PictureBox7.Bounds) Then
            PictureBox7.Image = My.Resources.gg7
            an7.Visible = False
            an7.Location = New Point(an7.Location.X + 1000, an7.Location.Y + 1000)
            x += 1
        End If
        If an8.Bounds.IntersectsWith(PictureBox8.Bounds) Then
            PictureBox8.Image = My.Resources.gg8
            an8.Visible = False
            an8.Location = New Point(an8.Location.X + 1000, an8.Location.Y + 1000)
            x += 1
        End If
        If an9.Bounds.IntersectsWith(PictureBox9.Bounds) Then
            PictureBox9.Image = My.Resources.gg9
            an9.Visible = False
            an9.Location = New Point(an9.Location.X + 1000, an9.Location.Y + 1000)
            x += 1
        End If
        If x = 9 Then
            x = 10
            gametotal += 1
            If Not gametotal = 4 Then
                game1 = 2
                MsgBox(Title:="MISSION ACCOMPLI", Prompt:="BRAVO! VOUS AVEZ CORRIGER L'IMAGE!")
                MsgBox(Title:="MISSION ACCOMPLI", Prompt:="IL VOUS RESTE " & 4 - gametotal & " MISSIONS!")
                Me.Dispose()
                Form6.Visible = True
            End If
        End If

    End Sub
End Class